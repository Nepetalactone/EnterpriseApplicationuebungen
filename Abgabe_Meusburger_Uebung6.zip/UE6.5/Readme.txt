Es m�ssen Stateful Beans verwendet werden

1) Bean auf dem Server deployen
2) Client ausf�hren