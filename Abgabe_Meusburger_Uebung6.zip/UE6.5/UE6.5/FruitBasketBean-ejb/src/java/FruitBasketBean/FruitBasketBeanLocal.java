/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FruitBasketBean;

import javax.ejb.Local;

/**
 *
 * @author Tobias
 */
@Local
public interface FruitBasketBeanLocal {

}
