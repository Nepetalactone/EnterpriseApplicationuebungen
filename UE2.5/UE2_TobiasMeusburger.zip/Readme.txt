1. Server starten
2. Client starten

Known Issues:
	-Client startet nicht ordnungsgem��
java.rmi.UnmarshalException: error unmarshalling return; nested exception is: 
	java.lang.ClassNotFoundException: atmserver.IATMFactory (no security manager: RMI class loader disabled)